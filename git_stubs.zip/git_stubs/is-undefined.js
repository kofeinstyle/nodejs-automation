export default function isUndefined(input) {
    return input === void 0;
}
