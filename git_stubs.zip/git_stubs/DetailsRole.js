"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var DetailsRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'details'
    }
  }],
  type: 'structure'
};
var _default = DetailsRole;
exports["default"] = _default;