// https://github.com/tc39/proposal-accessible-object-hasownproperty
require('../modules/esnext.object.has-own');
