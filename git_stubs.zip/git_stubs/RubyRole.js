"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var RubyRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'ruby'
    }
  }],
  type: 'structure'
};
var _default = RubyRole;
exports["default"] = _default;