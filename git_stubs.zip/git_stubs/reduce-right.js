var parent = require('../../stable/typed-array/reduce-right');

module.exports = parent;
