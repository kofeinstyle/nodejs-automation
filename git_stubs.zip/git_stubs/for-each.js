var parent = require('../../stable/typed-array/for-each');

module.exports = parent;
