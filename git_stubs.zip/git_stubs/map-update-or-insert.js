// TODO: remove from `core-js@4`
// https://github.com/tc39/proposal-upsert
require('./map-upsert');
