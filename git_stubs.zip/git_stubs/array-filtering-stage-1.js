// https://github.com/tc39/proposal-array-filtering
require('../modules/esnext.array.filter-reject');
require('../modules/esnext.typed-array.filter-reject');
